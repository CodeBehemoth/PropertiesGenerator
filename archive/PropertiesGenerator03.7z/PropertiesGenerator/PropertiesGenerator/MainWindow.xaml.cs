﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;

namespace PropertiesGenerator
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainWindowViewModel();
        }

        //private void TextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.Key == Key.Enter)
        //    {
        //        if (isLastItemSelected(sender as DependencyObject))
        //        {
        //            (DataContext as MainWindowViewModel).AddRow();
        //        }
        //    }
        //}

        //private bool isLastItemSelected(DependencyObject sender)
        //{
        //    ListBoxItem aParentItem = findParent<ListBoxItem>(sender);
        //    if (aParentItem != null && myListBox.Items.IndexOf( aParentItem ) == myListBox.Items.Count-1)
        //    {
        //        return true;
        //    }
        //    return false;
        //}

        //private void TextBox_PreviewKeyUp(object sender, KeyEventArgs e)
        //{
        //    if (e.Key == Key.Enter)
        //    {
        //        var request = new TraversalRequest(FocusNavigationDirection.Next);
        //        request.Wrapped = true;
        //        (sender as UIElement).MoveFocus(request);
        //    }
        //}

        //private static T findParent<T>(DependencyObject child) where T : DependencyObject
        //{
        //    //get parent item
        //    DependencyObject parentObject = VisualTreeHelper.GetParent(child);

        //    //we've reached the end of the tree
        //    if (parentObject == null) return null;

        //    //check if the parent matches the type we're looking for
        //    T parent = parentObject as T;
        //    if (parent != null)
        //        return parent;
        //    else
        //        return findParent<T>(parentObject);
        //}
    }

}
