﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace PropertiesGenerator
{

    public class PropertyDesription : ViewModelBase
    {
        public string PropertyType
        {
            get
            {
                return myPropertyType;
            }
            set
            {
                myPropertyType = value;
                RaisePropertyChanged(nameof(PropertyType));
            }
        }
        string myPropertyType;

        public string Name
        {
            get
            {
                return myName;
            }
            set
            {
                myName = value;
                RaisePropertyChanged();
            }
        }
        string myName;

        public string Comment
        {
            get
            {
                return myComment;
            }
            set
            {
                myComment = value;
                RaisePropertyChanged();
            }
        }
        string myComment;

        public PropertyDesription( string thePropertyType, string theName, string theComment)
        {
            PropertyType = thePropertyType;
            Name = theName;
            Comment = theComment;
        }
    }

    public class MainWindowViewModel : ViewModelBase
    {
        public ObservableCollection<string> SupportedTypes
        {
            get { return mySupportedTypes; }
            set
            {
                mySupportedTypes = value;
                RaisePropertyChanged();
            }
        }
        private ObservableCollection<string> mySupportedTypes;

        private ObservableCollection<PropertyDesription> myProps = new ObservableCollection<PropertyDesription>();
        public ObservableCollection<PropertyDesription> Properties
        {
            get
            {
                return myProps;
            }
            set
            {
                myProps = value;
                RaisePropertyChanged(nameof(Properties));
            }
        }

        /// <summary>
        /// Generated source code
        /// </summary>
        public string Code
        {
            get
            {
                return myCode;
            }
            set
            {
                myCode = value;
                RaisePropertyChanged(nameof(Code));
            }
        }

        

        string myCode;
        public ICommand CommandAddRow { get; private set; }
        public ICommand CommandGenerateCode { get; private set; }
        public ICommand CommandCopyToClipboard { get; private set; }
        private const string myIndent1 = "    ";
        private const string myIndent2 = "        ";
        private const string myIndent3 = "            ";
        private const string myIndent4 = "                ";

        public MainWindowViewModel()
        {
            SupportedTypes = new ObservableCollection<string>()
            {
                "string",
                "bool",
                "int",
                "long",
                "double",
                "float",
                "decimal",
                "object",
                "byte",
                "sbyte",   
                "char",    
                "uint",    
                "ulong",   
                "short",   
                "ushort"  
            };

            //create some rows
            for (int i = 0; i < 10; i++)
            {
                AddRow();
            }

            CommandAddRow = new RelayCommand( p1 => AddRow() );

            CommandGenerateCode = new RelayCommand( p1 =>
            {
                Code = "";
                foreach ( var aProp in Properties )
                {
                    if (!String.IsNullOrEmpty(aProp.Name))
                    {
                        string aPrivateName = "my" + aProp.Name;

                        string aPropCode = "";
                        aPropCode += myIndent1 + "/// <summary>" + Environment.NewLine;
                        aPropCode += myIndent1 + "/// " + aProp.Comment + Environment.NewLine;
                        aPropCode += myIndent1 + "/// </summary>" + Environment.NewLine;
                        aPropCode += myIndent1 + "public " + aProp.PropertyType + " " + aProp.Name + Environment.NewLine;
                        aPropCode += myIndent2 + "get" + Environment.NewLine;
                        aPropCode += myIndent2 + "{" + Environment.NewLine;
                        aPropCode += myIndent3 + "return my" + aProp.Name +";"+ Environment.NewLine;
                        aPropCode += myIndent2 + "}" + Environment.NewLine;
                        aPropCode += myIndent2 + "set" + Environment.NewLine;
                        aPropCode += myIndent2 + "{" + Environment.NewLine;
                        aPropCode += myIndent3 + "if ( " + aPrivateName + " != value )" + Environment.NewLine;
                        aPropCode += myIndent3 + "{" + Environment.NewLine;
                        aPropCode += myIndent4 + aPrivateName + " = value;" + Environment.NewLine;
                        aPropCode += myIndent4 + "RaisePropertyChanged(nameof(" + aProp.Name + "));" + Environment.NewLine;
                        aPropCode += myIndent3 + "}" + Environment.NewLine;
                        aPropCode += myIndent2 + "}" + Environment.NewLine;
                        aPropCode += myIndent1 + "private " + aProp.PropertyType + " " + aPrivateName + ";" + Environment.NewLine;
                        aPropCode += Environment.NewLine;
                        Code += aPropCode;
                    }
                }
            });

            CommandCopyToClipboard = new RelayCommand( p1 => Clipboard.SetText(Code) );

            Code = Environment.NewLine + "   Fill out the table and then press 'Generate Code'";
        }

        internal void AddRow()
        {
            Properties.Add(new PropertyDesription("string", "", ""));
        }
    }



}
