﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace PropertiesGenerator
{

    public class PropertyDesription : ViewModelBase
    {

        public Type PropertyType
        {
            get
            {
                return myPropertyType;
            }
            set
            {
                myPropertyType = value;
                RaisePropertyChanged();
            }
        }
        Type myPropertyType;

        public string Name
        {
            get
            {
                return myName;
            }
            set
            {
                myName = value;
                RaisePropertyChanged();
            }
        }
        string myName;

        public string Comment
        {
            get
            {
                return myComment;
            }
            set
            {
                myComment = value;
                RaisePropertyChanged();
            }
        }
        string myComment;

        public PropertyDesription( Type thePropertyType, string theName, string theComment)
        {
            PropertyType = thePropertyType;
            Name = theName;
            Comment = theComment;
        }
    }

    public class MainWindowViewModel : ViewModelBase
    {
        public ObservableCollection<Type> SupportedTypes
        {
            get { return mySupportedTypes; }
            set
            {
                mySupportedTypes = value;
                RaisePropertyChanged();
            }
        }
        private ObservableCollection<Type> mySupportedTypes;

        private ObservableCollection<PropertyDesription> myProps = new ObservableCollection<PropertyDesription>();
        public ObservableCollection<PropertyDesription> Properties
        {
            get
            {
                return myProps;
            }
            set
            {
                myProps = value;
                RaisePropertyChanged();
            }
        }

        /// <summary>
        /// Generated source code
        /// </summary>
        public string Code
        {
            get
            {
                return myCode;
            }
            set
            {
                myCode = value;
                RaisePropertyChanged();
            }
        }

        

        string myCode;
        public ICommand CommandAddRow { get; set; }
        public ICommand CommandGenerateCode { get; set; }
        private const string myIndent = "    ";

        public MainWindowViewModel()
        {
            SupportedTypes = new ObservableCollection<Type>()
            {
                typeof(string),
                typeof(int)
            };
            SupportedTypes.Add(typeof(double));

            Properties.Add(new PropertyDesription(typeof(string), "", ""));


            CommandAddRow = new RelayCommand(p1 =>
            {
                Properties.Add(new PropertyDesription(typeof(string), "", ""));
            });

            CommandGenerateCode = new RelayCommand(p1 =>
            {
                Code = "";
                foreach ( var aProp in Properties )
                {
                    if (!String.IsNullOrEmpty(aProp.Name))
                    {
                        string aPropCode = "";
                        aPropCode += myIndent + "/// <summary>" + Environment.NewLine;
                        aPropCode += myIndent + "/// " + aProp.Comment + Environment.NewLine;
                        aPropCode += myIndent + "/// </summary>" + Environment.NewLine;
                        aPropCode += myIndent + "public " + aProp.PropertyType + " " + aProp.Name + Environment.NewLine;
                        aPropCode += myIndent + myIndent + "get" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + "{" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + myIndent + "return my" + aProp.Name +";"+ Environment.NewLine;
                        aPropCode += myIndent + myIndent + "}" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + "set" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + "{" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + myIndent + "my" + aProp.Name + "= value;" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + myIndent + "RaisePropertyChanged();" + Environment.NewLine;
                        aPropCode += myIndent + myIndent + "}" + Environment.NewLine;
                        aPropCode += Environment.NewLine;
                        Code += aPropCode;
                    }
                }
            });


            Code = "press 'Generate Code'";
        }
    }



}
